"""Play in GCD-game"""
from game_template import template_game

print('Find the greatest common divisor of given numbers.')
template_game('game_gcd')

