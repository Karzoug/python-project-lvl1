"""docstring for cli file."""


def welcome_user():
    """Welcome user func."""
    name = input('May I have your name? ')
    print('Hello,', name, '!')
    
    return name
