"""Init for brain-games/scripts."""
