"""Play in Calc-game"""
from game_template import template_game

print('What is the result of the expression?')
template_game('game_calc')

