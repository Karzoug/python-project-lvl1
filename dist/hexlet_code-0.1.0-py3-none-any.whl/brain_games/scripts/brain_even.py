"""Play in Even-game"""
from .game_template import template_game

print('Answer "yes" if the number is even, otherwise answer "no".')
template_game('game_even')

